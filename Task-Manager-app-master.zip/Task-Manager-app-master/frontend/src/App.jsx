import TaskManager from './TaskManager';

function App() {
  return (
    <div>
      <TaskManager />
    </div>
  );
}

export default App;
